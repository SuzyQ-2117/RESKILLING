import React from 'react';

function Welcome() {
  return <h2>Everyday is a school day</h2>;
}

export default Welcome;
